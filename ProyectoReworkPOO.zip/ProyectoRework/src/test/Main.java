package test;

import controller.MainController;
import database.DBSession;
import view.Welcome;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ektmerida
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MainController GUI = new MainController(new Welcome(), new DBSession());
        GUI.init();
    }
    
}
