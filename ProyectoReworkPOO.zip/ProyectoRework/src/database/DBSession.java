/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author andre
 */
public class DBSession extends DBConnection{
    
    private boolean estadoSesion = false;
    private boolean esAdministrador = false;
    
    public boolean activarSesionCliente(String usuario, String contrasena){
    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection connection = getConnection();
    
    Boolean estado = false;
    
    try{
        ps = connection.prepareStatement("SELECT usuario, contrasena FROM client_cinema");
        rs = ps.executeQuery();
        
        while(rs.next()){
            String usuarioCorrecto = rs.getString("usuario");
            String contrasenaCorrecta = rs.getString("contrasena");
            
            if(usuario.equals(usuarioCorrecto) && contrasena.equals(contrasenaCorrecta)){
                this.estadoSesion = true;
                estado = true;
                break; // Termina el bucle si se encuentra una coincidencia
            }
        }
        
        if(!estado) {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
        }
        
    } catch(Exception ex){
        System.err.println("Error: " + ex);
    } finally {
        // Cerrar recursos (PreparedStatement, ResultSet, Connection) aquí
    }
    
    return estado;
}

    
    public boolean activarSesionAdministrador(String usuario, String contrasena) {  
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connection = getConnection();

        Boolean estado = false;

        try {
            ps = connection.prepareStatement("SELECT usuario, contrasena FROM manager_cinema");
            rs = ps.executeQuery();

            while (rs.next()) {
                String usuarioCorrecto = rs.getString("usuario");
                String contrasenaCorrecta = rs.getString("contrasena");

                if (usuario.equals(usuarioCorrecto) && contrasena.equals(contrasenaCorrecta)) {
                    // JOptionPane.showMessageDialog(null, "Bienvenido " + usuario);
                    this.estadoSesion = true;
                    this.esAdministrador = true;
                    estado = true;
                    break; // Termina el bucle si se encuentra una coincidencia
                }
            }

            if (!estado) {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
            }

        } catch (Exception ex) {
            System.err.println("Error: " + ex);
        } finally {
            // Cerrar recursos (PreparedStatement, ResultSet, Connection) aquí
        }

        return estado;
    }


    public boolean isEstadoSesion() {
        return estadoSesion;
    }

    public boolean isEsAdministrador() {
        return esAdministrador;
    }
}
