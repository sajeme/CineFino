/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ektmerida
 */
//Client hereda de Person
public class Client extends Person{

    public Client(String nombre, String apellido, int dia, int mes, int ano, String usuario, String contrasena, String correoElectronico) {
        super(nombre, apellido, dia, mes, ano, usuario, contrasena, correoElectronico);
    }

    public Client(){
        
    }
}
