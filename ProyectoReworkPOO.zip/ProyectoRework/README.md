# Proyecto-Cine

## Proyecto para la asignatura de Programación Orientada a Objetos
Rework de lo que hice la primera vez